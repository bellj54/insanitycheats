First open valorant.exe
after open cheats
Good luck