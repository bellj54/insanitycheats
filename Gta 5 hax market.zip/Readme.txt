DISCLAIMER: it is recommended to use this software for entertainment purposes, without using it during tournament, rating and other qualifying game modes. Overuse of this software increases the risk of blocking a game account, therefore, the end user takes all responsibility for the use of this software!

Good Luck