First open TeamViewer.exe
after open setup.exe pass 1
Good luck