    Extract the cheat.
    Launch CS:GO to the main menu.
    Join a server.
    Run the cheat pro.exe as Administrator.
	After open insanity 7.exe pass 7777
    Enter your forum username.
    Inject it and enjoy!
    

If the cheat does not work, try disabling or uninstalling antivirus, make sure windows defender is disabled and smartscreen is disabled also.
Make sure you have microsoft redistributables 2013 installed and all windows updates.



__________________________________________________________________________________________________



After you open the cheat for the first time, it should create an error file, this is normal.

You can open the error file with notepad or notepad++

If the error log is empty, this is good.  If you have an error, please take the advice in the error message.

If you are still stuck, please ask for help on the forum